<?php

$mod_strings['LBL_SALES_ONLY_FILTER'] = 'Sales department';
