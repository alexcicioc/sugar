<?php

$viewdefs['base']['view']['destinationcrm'] = array(
    'dashlets' => array(
        array(
            'label' => 'Destination CRM Latest news',
            'description' => 'Destination CRM Latest news',
            'config' => array(
            ),
            'preview' => array(
            ),
            'filter' => array(
            )
        ),
    ),
);
