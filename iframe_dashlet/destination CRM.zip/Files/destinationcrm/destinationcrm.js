({
    plugins: ['Dashlet']
})
